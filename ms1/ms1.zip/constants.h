#pragma once
namespace seneca {
   const size_t MaximumNumberOfMenuItems = 20u;
}
